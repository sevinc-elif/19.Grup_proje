#ifndef PROJE_H
#define PROJE_H

void promptYaz();

int komutIcra(char*[],int);

void showpid(int);
int cdKomutu(char*[]);

#endif